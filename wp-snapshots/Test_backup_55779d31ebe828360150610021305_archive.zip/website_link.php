<?php
define('WP_HOME','http://localhost:8888/test-revisr/');
define('WP_SITEURL','http://localhost:8888/test-revisr/');
?>
